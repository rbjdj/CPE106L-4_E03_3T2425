# Sentence Generator

This Python program generates random sentences based on simple grammar using words from vocabulary text files.

## How to Run

1. Make sure you have Python installed.
2. Run the program:

```bash
python generator_modified.py
```

3. Enter the number of sentences you'd like to generate.

## Vocabulary

The program uses the following files:
- `articles.txt`
- `nouns.txt`
- `verbs.txt`
- `prepositions.txt`

Each contains one word per line.
